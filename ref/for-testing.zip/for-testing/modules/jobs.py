jobs = {
    # Order : focal,compare,stopwords,delimiters,maxcost
    'job1' : ('reduced_deity', 'reduced_reward', 'stopwords', 'delimiters', 120),
    'job2' : ('reduced_gods', 'reduced_punishment', 'stopwords', 'delimiters', 120),
    'job3' : ('reduced_gods', 'reduced_reward', 'stopwords', 'delimiters', 120),
    'job4' : ('reduced_deity', 'ubc_morality', 'stopwords', 'delimiters', 120),
    'job5' : ('reduced_deity', 'ubc_emotion', 'stopwords', 'delimiters', 120),
    'job6' : ('reduced_deity', 'ubc_cognition', 'stopwords', 'delimiters', 120),
    'job7' : ('reduced_deity', 'ubc_religion', 'stopwords', 'delimiters', 120),
    'job8' : ('reduced_gods', 'ubc_morality', 'stopwords', 'delimiters', 120),
    'job9' : ('reduced_gods', 'ubc_emotion', 'stopwords', 'delimiters', 120),
    'job10' : ('reduced_gods', 'ubc_cognition', 'stopwords', 'delimiters', 120),
    'job11' : ('reduced_gods', 'ubc_religion', 'stopwords', 'delimiters', 120),
}